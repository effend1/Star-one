import java.util.Random;

/**
 * Interface RandomPlayer menyediakan kontrak untuk menghasilkan data pemain secara acak.
 * Soal 3
 */
interface RandomPlayer {
    void getRandomRole();
    void getRandomNamePlayer();
    
    // Default method untuk logic random attack dan traits (Soal 3)
    default int getRandomAttack(Player player) {
        Random rand = new Random();
        if (player.getRole().equalsIgnoreCase("Forward")) {
            // 200 - 700 kelipatan 100
            return (rand.nextInt(6) + 2) * 100;
        } else {
            // 300 - 500 kelipatan 50
            return (rand.nextInt(5) + 6) * 50;
        }
    }

    default String getRandomTraits(String role) {
        String[] forwardTraits = {"Knuckle Shot", "Power Shot", "Master Dribbler", "Speedster", "Power Header", 
                                  "Long Range Shooter", "Incisive Pass", "Agile Dribbler", "Clinical Finisher", "First Touch Master"};
        String[] defenderTraits = {"Aerial Dominance", "Aggressive Tackler", "Ball Interceptor", "Tactical Intelligence", 
                                   "Leadership", "Tackling Specialist", "Positioning Master", "Bruiser", "Clean Tackler", "Ball Winning"};
        Random rand = new Random();
        return role.equalsIgnoreCase("Forward") ? forwardTraits[rand.nextInt(10)] : defenderTraits[rand.nextInt(10)];
    }
}

/**
 * Abstract Class Player sebagai induk dari karakter Forward dan Defender.
 * Mengimplementasikan RandomPlayer (Soal 3).
 */
abstract class Player implements RandomPlayer {
    protected String role;
    protected String name;
    protected String attribute;
    protected int attack;
    protected int defense;
    protected String traits;

    // Array data untuk Soal 3 & 4
    protected static final String[] FORWARD_NAMES = {"Julian Alvarez", "Kylian Mbappe", "Erling Haaland", "Lionel Messi", "Cristiano Ronaldo", "Neymar", "Benjamin Sesko", "Robert Lewandowski", "Mohamed Salah", "Bryan Mbuemo"};
    protected static final String[] DEFENDER_NAMES = {"Virgil van Dijk", "William Saliba", "Leny Yoro", "Reece James", "Marc Cucurella", "Matthijs de Ligt", "Luke Shaw", "N'Golo Kante", "Casemiro", "Adam Wharton"};
    protected static final String[] SPECIAL_ABILITY_FORWARD = {"Elastico", "Sombrero Flick", "Rabona", "Rainbow Flick", "Heel to Heel", "Step Over", "Maradona Turn", "Cruyff Turn", "Inverted Scissors", "Double Step Over"};
    protected static final String[] SPECIAL_ABILITY_DEFENDER = {"Block", "Tackle", "Intercept", "Clearance", "Slide Tackle", "Shoulder Barge", "Positioning", "Marking", "Tackling Specialist", "Ball Winner"};

    // Constructor Overloading (Soal 1)
    public Player() {
        getRandomRole();
        getRandomNamePlayer();
        this.attribute = getRandomAttribute();
        this.attack = getRandomAttack(this);
        setDefenseByAttribute();
        this.traits = getRandomTraits(this.role);
    }

    public Player(String name, String attribute, int attack, String traits) {
        this.name = name;
        this.attribute = attribute;
        this.attack = attack;
        this.traits = traits;
    }

    // Abstract Method (Soal 2)
    public abstract void displayInfo();

    // Helper untuk Soal 1: Set Defense berdasarkan Tabel
    protected void setDefenseByAttribute() {
        if (this instanceof Forward) {
            if (attribute.equalsIgnoreCase("Power")) this.defense = 100;
            else if (attribute.equalsIgnoreCase("Intelligence")) this.defense = 200;
            else this.defense = 300; // Strength
        } else if (this instanceof Defender) {
            if (attribute.equalsIgnoreCase("Power")) this.defense = 150;
            else if (attribute.equalsIgnoreCase("Intelligence")) this.defense = 250;
            else this.defense = 350; // Strength
        }
    }

    private String getRandomAttribute() {
        String[] attrs = {"Power", "Intelligence", "Strength"};
        return attrs[new Random().nextInt(3)];
    }

    // Implementasi Interface (Soal 3)
    @Override
    public void getRandomRole() {
        this.role = new Random().nextBoolean() ? "Forward" : "Defender";
    }

    @Override
    public void getRandomNamePlayer() {
        Random rand = new Random();
        if (this.role.equalsIgnoreCase("Forward")) this.name = FORWARD_NAMES[rand.nextInt(10)];
        else this.name = DEFENDER_NAMES[rand.nextInt(10)];
    }

    // Getter & Setter
    public String getRole() { return role; }
    public String getName() { return name; }
    public int getAttack() { return attack; }
    public int getDefense() { return defense; }
    public String getAttribute() { return attribute; }
}

/**
 * Sub-class Forward
 */
class Forward extends Player {
    private String specialAbility;

    public Forward(String name, String attribute, int attack, String traits, String specialAbility) {
        super(name, attribute, attack, traits);
        this.role = "Forward";
        this.specialAbility = specialAbility;
        setDefenseByAttribute();
    }

    public Forward(String name, int attack, String traits, String specialAbility) {
        this(name, "Intelligence", attack, traits, specialAbility); // Default random attribute via logic
    }

    // Constructor untuk Soal 3 (Full Random)
    public Forward() {
        super();
        this.role = "Forward";
        this.specialAbility = SPECIAL_ABILITY_FORWARD[new Random().nextInt(10)];
    }

    @Override
    public void displayInfo() {
        System.out.println("Role: " + role);
        System.out.println("Nama : " + name);
        System.out.println("Atribut: " + attribute);
        System.out.println("Attack: " + attack);
        System.out.println("Defense: " + defense);
        System.out.println("Traits: " + traits);
        System.out.println("Ability: " + specialAbility);
    }
}

/**
 * Sub-class Defender
 */
class Defender extends Player {
    private String specialAbility;

    public Defender(String name, String attribute, int attack, String traits, String specialAbility) {
        super(name, attribute, attack, traits);
        this.role = "Defender";
        this.specialAbility = specialAbility;
        setDefenseByAttribute();
    }

    public Defender() {
        super();
        this.role = "Defender";
        this.specialAbility = SPECIAL_ABILITY_DEFENDER[new Random().nextInt(10)];
    }

    @Override
    public void displayInfo() {
        System.out.println("Role: " + role);
        System.out.println("Nama : " + name);
        System.out.println("Atribut: " + attribute);
        System.out.println("Attack: " + attack);
        System.out.println("Defense: " + defense);
        System.out.println("Traits: " + traits);
        System.out.println("Ability: " + specialAbility);
    }
}

/**
 * Class utama untuk menjalankan simulasi pertandingan sepak bola Head To Head.
 * Program ini mencakup implementasi konsep OOP seperti Inheritance, 
 * Abstract Class, Interface, dan Polymorphism.
 */
public class Tugas4_1402022046 { 

    /**
     * soal 5 : Memberikan bonus statistik (buff) kepada pemain berdasarkan atributnya.
     * 
     * @param player Objek pemain yang akan diberikan buff.
     * @return Array int berisi {bonusAttack, bonusDefense}.
     */
    public static int[] applyBuff(Player player) {
        Random rand = new Random();
        int bonusAttack = 0;
        int bonusDefense = 0;
        String attr = player.getAttribute().toLowerCase();

        switch (attr) {
            case "power":
                bonusAttack = rand.nextInt(101) + 50; // 50 - 150
                break;
            case "intelligence":
                bonusDefense = rand.nextInt(121) + 80; // 80 - 200
                break;
            case "strength":
                bonusAttack = rand.nextInt(81) + 40; // 40 - 120
                bonusDefense = rand.nextInt(81) + 40; // 40 - 120
                break;
        }
        return new int[]{bonusAttack, bonusDefense};
    }

    /**
     * Soal 4 dan 5: Simulasi Pertandingan antara Forward dan Defender.
     * Menggunakan simbol 'dan' sebagai pengganti ampersand untuk menghindari error HTML.
     * 
     * @param forward Objek pemain dengan role Forward.
     * @param defender Objek pemain dengan role Defender.
     */
    public static void simulateMatch(Player forward, Player defender) {
        System.out.println("=== STATISTIK FORWARD ===");
        forward.displayInfo();
        System.out.println("\n=== STATISTIK DEFENDER ===");
        defender.displayInfo();
        
        System.out.println("\n=============================================");
        System.out.println("          HEAD TO HEAD SIMULATION ");
        System.out.println("=============================================");
        System.out.println("Applying Buffs...");

        int[] fBuff = applyBuff(forward);
        int[] dBuff = applyBuff(defender);

        int fTotal = (forward.getAttack() + forward.getDefense()) + fBuff[0] + fBuff[1];
        int dTotal = (defender.getAttack() + defender.getDefense()) + dBuff[0] + dBuff[1];

        System.out.printf("%s (Forward)  -> Total Power : %d  [Base: %d | Buff: +%d]\n", 
            forward.getName(), fTotal, (forward.getAttack()+forward.getDefense()), (fBuff[0]+fBuff[1]));
        System.out.println("                     VS");
        System.out.printf("%s (Defender) -> Total Power : %d  [Base: %d | Buff: +%d]\n", 
            defender.getName(), dTotal, (defender.getAttack()+defender.getDefense()), (dBuff[0]+dBuff[1]));
        
        System.out.println("---------------------------------------------");
        if (fTotal > dTotal) {
            System.out.println("Pemenang: " + forward.getName());
            System.out.println(forward.getName() + " berhasil menembus pertahanan!");
        } else if (dTotal > fTotal) {
            System.out.println("Pemenang: " + defender.getName());
            System.out.println(defender.getName() + " berhasil menghalau bola!");
        } else {
            System.out.println("Hasil Seri!");
        }
        System.out.println("=============================================");
    }

    /**
     * Method utama untuk menjalankan program simulasi Head To Head.
     * 
     * @param args Argumen baris perintah (tidak digunakan).
     */
    public static void main(String[] args) {
        // Contoh Eksekusi Soal 1
        System.out.println("--- SOAL 1: MANUAL INPUT ---");
        Player p1 = new Forward("Kylian Mbappe", "Power", 200, "Knuckle Shot", "Rainbow Flick");
        p1.displayInfo();
        System.out.println();

        // Contoh Eksekusi Soal 4 & 5
        System.out.println("--- SOAL 4 & 5: SIMULASI RANDOM ---");
        
        // Memastikan mendapatkan Forward
        Player fObj = new Forward();
        // Memastikan mendapatkan Defender
        Player dObj = new Defender();

        simulateMatch(fObj, dObj);
    }
}